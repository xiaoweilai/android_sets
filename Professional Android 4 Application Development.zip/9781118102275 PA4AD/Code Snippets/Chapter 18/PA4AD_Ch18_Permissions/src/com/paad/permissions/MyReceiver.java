package com.paad.permissions;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MyReceiver extends BroadcastReceiver {
  
  public static final String ACTION_DETONATE_DEVICE = "com.paad.ACTION_DETONATE_DEVICE";

  @Override
  public void onReceive(Context context, Intent intent) {
    // TODO Handle Received Broadcast
  }

}
