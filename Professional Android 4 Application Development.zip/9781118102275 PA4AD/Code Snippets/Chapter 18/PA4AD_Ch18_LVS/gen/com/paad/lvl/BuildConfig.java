/** Automatically generated file. DO NOT MODIFY */
package com.paad.lvl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}