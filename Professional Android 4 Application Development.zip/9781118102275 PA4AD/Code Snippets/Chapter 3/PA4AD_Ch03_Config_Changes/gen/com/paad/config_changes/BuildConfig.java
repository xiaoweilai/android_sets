/** Automatically generated file. DO NOT MODIFY */
package com.paad.config_changes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}