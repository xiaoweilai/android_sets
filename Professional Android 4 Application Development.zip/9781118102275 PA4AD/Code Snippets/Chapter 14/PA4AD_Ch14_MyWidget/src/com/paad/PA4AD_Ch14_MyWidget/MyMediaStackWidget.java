package com.paad.PA4AD_Ch14_MyWidget;

import android.appwidget.AppWidgetProvider;

public class MyMediaStackWidget extends AppWidgetProvider {}