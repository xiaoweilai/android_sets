package com.paad.PA4AD_Ch14_MyWidget;

import android.app.Activity;
import android.os.Bundle;

public class LiveWallpaperConfiguration extends Activity {

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.main);    
  }
  
}