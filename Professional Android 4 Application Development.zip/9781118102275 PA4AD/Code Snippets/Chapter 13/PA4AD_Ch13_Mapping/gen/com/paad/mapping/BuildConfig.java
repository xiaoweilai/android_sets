/** Automatically generated file. DO NOT MODIFY */
package com.paad.mapping;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}