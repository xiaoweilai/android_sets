/**
 * Listing 13-12: A skeleton map Activity
 * [MOVED TO MyMapActivity.java]
 */
//import com.google.android.maps.MapActivity;
//import com.google.android.maps.MapController;
//import com.google.android.maps.MapView;
//import android.os.Bundle;
//
//public class MyActivity extends MapActivity {
//  private MapView mapView;
//
//  private MapController mapController;
//
//  @Override
//  public void onCreate(Bundle savedInstanceState) {
//    super.onCreate(savedInstanceState);
//    setContentView(R.layout.map_layout);
//    mapView = (MapView)findViewById(R.id.map_view);
//  }
//
//  @Override
//  protected boolean isRouteDisplayed() {
//    // IMPORTANT: This method must return true if your Activity
//    // is displaying driving directions. Otherwise return false.
//    return false;
//  }
//}