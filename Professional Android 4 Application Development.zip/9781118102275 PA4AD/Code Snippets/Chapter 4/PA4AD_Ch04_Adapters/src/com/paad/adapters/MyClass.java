package com.paad.adapters;

public class MyClass {

}
