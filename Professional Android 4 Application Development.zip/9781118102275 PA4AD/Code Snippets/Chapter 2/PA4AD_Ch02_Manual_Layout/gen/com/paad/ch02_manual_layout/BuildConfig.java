/** Automatically generated file. DO NOT MODIFY */
package com.paad.ch02_manual_layout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}